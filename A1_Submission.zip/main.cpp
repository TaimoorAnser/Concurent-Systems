
#include <iostream>
#include <string>
#include <thread>
#include "Competitor.h"
#include "ThreadMap.h"
#include <ctime>        // Additional for the random number generation
#include <cstdlib>
#include <random>
#include <windows.h>

const int NO_TEAMS = 4; 	// number of teams in the race
const int NO_MEMBERS = 4;	// number of athletes in the team
using namespace std;

std::mt19937 gen(time(0)); // Seed to ensure that the numbers generated are truly random

ThreadMap threadmap1; // Declaring the thread_map as a global variable

void run(Competitor& c) { // Run function which generates a random value and assign it to the competitor

    threadmap1.insertThreadPair(c); // The competitor is inserted into the thread_map

    std::uniform_real_distribution<double> dis(9,15); // A random double value is generated between the range of 9 and 15

    double n = dis(gen); // Double value generated and store in the variable n

    n = round( n * 1000.0 ) / 1000.0; // Rounding done to make the double value to 3.d.p

    cout<<n<<endl; // This prints out the value of the time in which the competitor completes his run.

}

int main() {
    thread test[4][4];
    thread theThreads[NO_TEAMS][NO_MEMBERS];
    Competitor teamsAndMembers[NO_TEAMS][NO_MEMBERS];

    // define elements of teamsAndMembers
    Competitor b1("Blue","Bob");
    Competitor b2("Blue","Tim");
    Competitor b3("Blue","John");
    Competitor b4("Blue","Guy");

    Competitor r1("Red","Aang");
    Competitor r2("Red","Iroh");
    Competitor r3("Red","Zuko");
    Competitor r4("Red","Kora");

    Competitor g1("Green","Ruko");
    Competitor g2("Green","Pakku");
    Competitor g3("Green","Teo");
    Competitor g4("Green","Chey");

    Competitor y1("Yellow","Jet");
    Competitor y2("Yellow","Feng");
    Competitor y3("Yellow","Appa");
    Competitor y4("Yellow","Lee");

// create threads (elements of theThreads)
    teamsAndMembers[0][0] = b1;  // The first row of the array is all team blue
    teamsAndMembers[0][1] = b2;
    teamsAndMembers[0][2] = b3;
    teamsAndMembers[0][3] = b4;

    teamsAndMembers[1][0] = r1; // The second row of the array is all team red
    teamsAndMembers[1][1] = r2;
    teamsAndMembers[1][2] = r3;
    teamsAndMembers[1][3] = r4;

    teamsAndMembers[2][0] = g1; // The third row of the array is all team green
    teamsAndMembers[2][1] = g2;
    teamsAndMembers[2][2] = g3;
    teamsAndMembers[2][3] = g4;

    teamsAndMembers[3][0] = y1;// The fourth row of the array is all team yellow
    teamsAndMembers[3][1] = y2;
    teamsAndMembers[3][2] = y3;
    teamsAndMembers[3][3] = y4;

// The for loop below is used to assign threads to an array
    for(int i =0;i<4;i++)
    {
        for(int j =0;j<4;j++)
        {

            test[i][j] = thread(run,std::ref(teamsAndMembers[i][j]));

        }
    }

// This for loop is used to join all of the threads
    for(int i =0;i<4;i++)
    {
        for(int j =0;j<4;j++)
        {
            test[i][j].join();
        }
    }


    threadmap1.printMapContents(); // Printing the contents of the map with thread id, followed by the competitor
}
