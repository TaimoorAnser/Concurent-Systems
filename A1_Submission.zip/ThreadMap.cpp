#include "ThreadMap.h"

ThreadMap::ThreadMap() {};


void ThreadMap::insertThreadPair(Competitor c) {

    auto thread_id = std::this_thread::get_id(); // Getting the thread_id of the running thread with the competitor
    auto pair2 = std::make_pair(thread_id,c);    // Making a thread_id and competitor pair
    threadComp.insert(pair2);                    // Inserting the generated pair into the thread map
}

Competitor ThreadMap::getThreadId() {
	std::map <std::thread::id, Competitor>::iterator it = threadComp.find(std::this_thread::get_id());
	if (it == threadComp.end())
		return Competitor::makeNull();						//	alternatively	return *(new Competitor(" ", " "));
	else
		return it->second;									// i.e. the second item in the pair
}

void ThreadMap::printMapContents() {
	std::cout << "MAP CONTENTS:" << std::endl;

    for (auto& p : threadComp ) {
        std::cout<<"Thread id: "<<p.first<<" , "<<"Competitor: " << p.second.getPerson() << endl;
    }

	cout << "END MAP CONTENTS" << endl;
}

int ThreadMap::ThreadMapSize() { return threadComp.size(); }
