This zip file contains:
- The Competitor Class (.h and .cpp)
- Part of the ThreadMap class (.h and .cpp)
- A main program (AssignmentPart1.cpp) that creates a Competitor object and a ThreadManager Object and which contains a 'commented out' skeleton version of main from the lab script for part 1
- Visual Studio project files

If you double click on AssignmentPart1.cbp on a machine with CodeBlocks installed, the project should be opened.

The project will compile and run, but won't do anything useful until the ThreadMap class is completed.

